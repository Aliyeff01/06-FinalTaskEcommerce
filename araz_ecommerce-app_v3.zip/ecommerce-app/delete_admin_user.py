from app import app, db
from database import User

with app.app_context():
    # Find the admin user by email
    admin_user = User.query.filter_by(email='admin@gmail.com').first()
    
    if admin_user:
        db.session.delete(admin_user)
        db.session.commit()
        print("Admin user deleted.")
    else:
        print("Admin user not found.")
