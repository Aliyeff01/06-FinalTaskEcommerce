from app import create_product_app
from database import Product, product_db
from datetime import datetime

# Create sample products
sample_products = [
    {"name": "Karabakh FC Home Kit", "price": 79.99, "date_posted": datetime.utcnow()},
    {"name": "Karabakh FC Away Kit", "price": 79.99, "date_posted": datetime.utcnow()},
    {"name": "Real Madrid Home Kit", "price": 89.99, "date_posted": datetime.utcnow()},
    {"name": "Barcelona Home Kit", "price": 89.99, "date_posted": datetime.utcnow()},
    {"name": "Chelsea Home Kit", "price": 84.99, "date_posted": datetime.utcnow()},
    {"name": "Manchester United Home Kit", "price": 84.99, "date_posted": datetime.utcnow()},
    {"name": "Juventus Home Kit", "price": 89.99, "date_posted": datetime.utcnow()},
]

product_app = create_product_app()

with product_app.app_context():
    for product_data in sample_products:
        existing_product = Product.query.filter_by(name=product_data["name"]).first()
        if existing_product:
            print(f"Product {product_data['name']} already exists.")
        else:
            product = Product(
                name=product_data["name"],
                price=product_data["price"],
                date_posted=product_data["date_posted"],
                user_id=1  # Assuming an admin user with ID 1 exists
            )
            product_db.session.add(product)
    product_db.session.commit()
    print("Sample products added successfully.")
