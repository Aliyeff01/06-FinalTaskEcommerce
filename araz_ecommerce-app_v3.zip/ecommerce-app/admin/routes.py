from flask import render_template, url_for, flash, redirect, request, Blueprint, session, current_app
from database import user_db, product_db, User, Product, create_user_app, create_product_app
from functools import wraps
from werkzeug.security import check_password_hash

admin = Blueprint('admin', __name__, template_folder='templates/admin')

user_app = create_user_app()
product_app = create_product_app()

def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if 'user_id' not in session or not session.get('is_admin'):
            flash('You do not have permission to access this page.', 'danger')
            return redirect(url_for('main.home'))
        return fn(*args, **kwargs)
    return wrapper

@admin.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        with user_app.app_context():
            user = user_db.session.query(User).filter_by(username=username).first()
        if user and check_password_hash(user.password, password) and user.is_admin:
            session['user_id'] = user.id
            session['username'] = user.username
            session['is_admin'] = user.is_admin
            flash('Admin login successful!', 'success')
            return redirect(url_for('admin.manage_products'))
        else:
            flash('Login Unsuccessful. Please check username and password', 'danger')
    return render_template('login.html')

@admin.route('/admin/add_product', methods=['GET', 'POST'])
@admin_required
def add_product():
    if request.method == 'POST':
        name = request.form.get('name')
        price = request.form.get('price')
        with product_app.app_context():
            product = Product(name=name, price=price, user_id=session['user_id'])
            product_db.session.add(product)
            product_db.session.commit()
        flash('Product added successfully!', 'success')
    return render_template('add_product.html')

@admin.route('/admin/products', methods=['GET', 'POST'])
@admin_required
def manage_products():
    if request.method == 'POST':
        name = request.form.get('name')
        price = request.form.get('price')
        with product_app.app_context():
            product = Product(name=name, price=price, user_id=session['user_id'])
            product_db.session.add(product)
            product_db.session.commit()
        flash('Product added successfully!', 'success')
    with product_app.app_context():
        products = product_db.session.query(Product).all()
    return render_template('manage_products.html', products=products)

@admin.route('/admin/products/edit/<int:product_id>', methods=['GET', 'POST'])
@admin_required
def edit_product(product_id):
    with product_app.app_context():
        product = product_db.session.query(Product).get_or_404(product_id)
    if request.method == 'POST':
        with product_app.app_context():
            product.name = request.form.get('name')
            product.price = request.form.get('price')
            product_db.session.commit()
        flash('Product updated successfully!', 'success')
        return redirect(url_for('admin.manage_products'))
    return render_template('edit_product.html', product=product)

@admin.route('/admin/products/delete/<int:product_id>', methods=['POST'])
@admin_required
def delete_product(product_id):
    with product_app.app_context():
        product = product_db.session.query(Product).get_or_404(product_id)
        product_db.session.delete(product)
        product_db.session.commit()
    flash('Product deleted successfully!', 'success')
    return redirect(url_for('admin.manage_products'))

@admin.route('/admin/users', methods=['GET', 'POST'])
@admin_required
def manage_users():
    with user_app.app_context():
        users = user_db.session.query(User).all()
    return render_template('manage_users.html', users=users)

@admin.route('/admin/users/delete/<int:user_id>', methods=['POST'])
@admin_required
def delete_user(user_id):
    with user_app.app_context():
        user = user_db.session.query(User).get_or_404(user_id)
        user_db.session.delete(user)
        user_db.session.commit()
    flash('User deleted successfully!', 'success')
    return redirect(url_for('admin.manage_users'))

@admin.route('/admin/users/toggle_admin/<int:user_id>', methods=['POST'])
@admin_required
def toggle_admin(user_id):
    with user_app.app_context():
        user = user_db.session.query(User).get_or_404(user_id)
        user.is_admin = not user.is_admin
        user_db.session.commit()
    flash('User admin status updated successfully!', 'success')
    return redirect(url_for('admin.manage_users'))

@admin.route('/admin/view_products')
@admin_required
def view_products():
    with product_app.app_context():
        products = product_db.session.query(Product).all()
    with user_db.session() as db_session:
        users = {user.id: user.username for user in db_session.query(User).all()}
    return render_template('view_products.html', products=products, users=users)


@admin.route('/admin/view_users')
@admin_required
def view_users():
    with user_app.app_context():
        users = user_db.session.query(User).all()
    return render_template('view_users.html', users=users)
