from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

class UserConfig:
    SQLALCHEMY_DATABASE_URI = 'sqlite:///users.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False

class ProductConfig:
    SQLALCHEMY_DATABASE_URI = 'sqlite:///products.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False

user_db = SQLAlchemy()
product_db = SQLAlchemy()

def create_user_app():
    app = Flask(__name__)
    app.config.from_object(UserConfig)
    user_db.init_app(app)
    return app

def create_product_app():
    app = Flask(__name__)
    app.config.from_object(ProductConfig)
    product_db.init_app(app)
    return app

# Define association tables without foreign key constraints
class BasketItem(product_db.Model):
    __tablename__ = 'basket_items'
    user_id = product_db.Column(product_db.Integer, primary_key=True)
    product_id = product_db.Column(product_db.Integer, primary_key=True)

class FavoriteItem(product_db.Model):
    __tablename__ = 'favorite_items'
    user_id = product_db.Column(product_db.Integer, primary_key=True)
    product_id = product_db.Column(product_db.Integer, primary_key=True)

class User(user_db.Model):
    id = user_db.Column(user_db.Integer, primary_key=True)
    username = user_db.Column(user_db.String(20), unique=True, nullable=False)
    email = user_db.Column(user_db.String(120), unique=True, nullable=False)
    password = user_db.Column(user_db.String(60), nullable=False)
    is_admin = user_db.Column(user_db.Boolean, default=False)

class Product(product_db.Model):
    id = product_db.Column(product_db.Integer, primary_key=True)
    name = product_db.Column(product_db.String(100), nullable=False)
    price = product_db.Column(product_db.Float, nullable=False)
    date_posted = product_db.Column(product_db.DateTime, nullable=False, default=datetime.now)
    user_id = product_db.Column(product_db.Integer, nullable=False)
