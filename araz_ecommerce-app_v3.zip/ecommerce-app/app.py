from flask import Flask
from flask_bcrypt import Bcrypt
from flask_jwt_extended import JWTManager
from database import create_user_app, create_product_app, user_db, product_db

bcrypt = Bcrypt()
jwt = JWTManager()

user_app = create_user_app()
product_app = create_product_app()

def create_app():
    app = user_app
    app.config['SECRET_KEY'] = 'sqlite_arazecom'
    app.config['JWT_SECRET_KEY'] = 'jwt_arazecom'
    app.config['JWT_TOKEN_LOCATION'] = ['cookies']
    app.config['JWT_ACCESS_COOKIE_NAME'] = 'access_token_cookie'
    app.config['JWT_COOKIE_CSRF_PROTECT'] = False

    bcrypt.init_app(app)
    jwt.init_app(app)

    from main.routes import main as main_blueprint
    app.register_blueprint(main_blueprint)

    from admin.routes import admin as admin_blueprint
    app.register_blueprint(admin_blueprint, url_prefix='/admin')

    return app

if __name__ == "__main__":
    app = create_app()

    with user_app.app_context():
        user_db.create_all()

    with product_app.app_context():
        product_db.create_all()

    app.run(debug=True)
