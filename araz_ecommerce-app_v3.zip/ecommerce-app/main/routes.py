from flask import render_template, url_for, flash, redirect, request, Blueprint, session, jsonify, make_response, current_app
from database import user_db, product_db, User, Product, create_product_app, BasketItem, FavoriteItem
from flask_jwt_extended import create_access_token, set_access_cookies, unset_jwt_cookies, jwt_required, get_jwt_identity
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps

main = Blueprint('main', __name__, template_folder='templates/main')

product_app = create_product_app()

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('user_id'):
            flash('Login first to access this page!', 'danger')
            return render_template('login_first.html')
        return f(*args, **kwargs)
    return decorated_function

@main.route('/')
def home():
    sort_by = request.args.get('sort_by', 'name')
    with product_app.app_context():
        if sort_by == 'price':
            products = product_db.session.query(Product).order_by(Product.price).all()
        elif sort_by == 'date_posted':
            products = product_db.session.query(Product).order_by(Product.date_posted).all()
        else:
            products = product_db.session.query(Product).order_by(Product.name).all()
    username = session.get('username')
    return render_template('index.html', products=products, username=username)

@main.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        with current_app.app_context():
            user = user_db.session.query(User).filter_by(username=username).first()
        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            session['username'] = user.username
            session['is_admin'] = user.is_admin  # Ensure this is set
            access_token = create_access_token(identity=user.id)
            response = make_response(redirect(url_for('main.home')))
            set_access_cookies(response, access_token)
            flash('Login successful!', 'success')
            return response
        else:
            flash('Login Unsuccessful. Please check username and password', 'danger')
    return render_template('login.html')

@main.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        with user_db.session() as db_session:
            existing_user = db_session.query(User).filter((User.username == username) | (User.email == email)).first()
        if existing_user:
            flash('Username or Email already exists. Please choose a different one.', 'danger')
            return redirect(url_for('main.register'))
        hashed_password = generate_password_hash(password, method='pbkdf2:sha256')
        user = User(username=username, email=email, password=hashed_password, is_admin=False)
        with user_db.session() as db_session:
            db_session.add(user)
            db_session.commit()
        flash('Your account has been created! You are now able to log in', 'success')
        return redirect(url_for('main.login'))
    return render_template('register.html')

@main.route('/logout')
def logout():
    response = make_response(redirect(url_for('main.login')))
    unset_jwt_cookies(response)
    session.pop('user_id', None)
    session.pop('username', None)
    session.pop('is_admin', None)
    flash('You have been logged out!', 'success')
    return response

@main.route('/profile')
@jwt_required(optional=True)
def profile():
    if not get_jwt_identity():
        flash('Login first to access this page!', 'danger')
        return render_template('login_first.html')
    user_id = get_jwt_identity()
    with user_db.session() as db_session:
        user = db_session.query(User).get(user_id)
    return render_template('profile.html', user=user, username=session.get('username'))

@main.route('/basket')
@jwt_required(optional=True)
def basket():
    if not get_jwt_identity():
        flash('Login first to access this page!', 'danger')
        return render_template('login_first.html')
    user_id = get_jwt_identity()
    with user_db.session() as db_session:
        user = db_session.query(User).get(user_id)
    with product_app.app_context():
        basket_items = product_db.session.query(Product).join(
            BasketItem, (BasketItem.product_id == Product.id)
        ).filter(BasketItem.user_id == user.id).all()
    return render_template('basket.html', basket_items=basket_items, username=session.get('username'))

@main.route('/favorites')
@jwt_required(optional=True)
def favorites():
    if not get_jwt_identity():
        flash('Login first to access this page!', 'danger')
        return render_template('login_first.html')
    user_id = get_jwt_identity()
    with user_db.session() as db_session:
        user = db_session.query(User).get(user_id)
    with product_app.app_context():
        favorite_items = product_db.session.query(Product).join(
            FavoriteItem, (FavoriteItem.product_id == Product.id)
        ).filter(FavoriteItem.user_id == user.id).all()
    return render_template('favorites.html', favorite_items=favorite_items, username=session.get('username'))

@main.route('/add_to_basket/<int:product_id>', methods=['POST'])
@login_required
@jwt_required()
def add_to_basket(product_id):
    user_id = get_jwt_identity()
    with user_db.session() as db_session:
        user = db_session.query(User).get(user_id)
    with product_app.app_context():
        product = product_db.session.query(Product).get(product_id)
        new_basket_item = BasketItem(user_id=user.id, product_id=product.id)
        product_db.session.add(new_basket_item)
        product_db.session.commit()
    flash('Product added to basket!', 'success')
    return redirect(url_for('main.home'))

@main.route('/remove_from_basket/<int:product_id>', methods=['POST'])
@jwt_required()
def remove_from_basket(product_id):
    user_id = get_jwt_identity()
    with product_app.app_context():
        basket_item = product_db.session.query(BasketItem).filter_by(user_id=user_id, product_id=product_id).first()
        if basket_item:
            product_db.session.delete(basket_item)
            product_db.session.commit()
            flash('Product removed from basket!', 'success')
        else:
            flash('Product not found in basket.', 'danger')
    return redirect(url_for('main.basket'))

@main.route('/add_to_favorites/<int:product_id>', methods=['POST'])
@login_required
@jwt_required()
def add_to_favorites(product_id):
    user_id = get_jwt_identity()
    with user_db.session() as db_session:
        user = db_session.query(User).get(user_id)
    with product_app.app_context():
        product = product_db.session.query(Product).get(product_id)
        new_favorite_item = FavoriteItem(user_id=user.id, product_id=product.id)
        product_db.session.add(new_favorite_item)
        product_db.session.commit()
    flash('Product added to favorites!', 'success')
    return redirect(url_for('main.home'))

@main.route('/remove_from_favorites/<int:product_id>', methods=['POST'])
@jwt_required()
def remove_from_favorites(product_id):
    user_id = get_jwt_identity()
    with product_app.app_context():
        favorite_item = product_db.session.query(FavoriteItem).filter_by(user_id=user_id, product_id=product_id).first()
        if favorite_item:
            product_db.session.delete(favorite_item)
            product_db.session.commit()
            flash('Product removed from favorites!', 'success')
        else:
            flash('Product not found in favorites.', 'danger')
    return redirect(url_for('main.favorites'))

@main.route('/api/login', methods=['POST'])
def api_login():
    username = request.json.get('username', None)
    password = request.json.get('password', None)
    with user_db.session() as db_session:
        user = db_session.query(User).filter_by(username=username).first()
    if user and check_password_hash(user.password, password):
        access_token = create_access_token(identity=user.id)
        response = jsonify(access_token=access_token)
        set_access_cookies(response, access_token)
        return response
    return jsonify({"msg": "Bad username or password"}), 401

@main.route('/api/register', methods=['POST'])
def api_register():
    username = request.json.get('username', None)
    email = request.json.get('email', None)
    password = request.json.get('password', None)
    with user_db.session() as db_session:
        existing_user = db_session.query(User).filter((User.username == username) | (User.email == email)).first()
    if existing_user:
        return jsonify({"msg": "Username or Email already exists"}), 400
    hashed_password = generate_password_hash(password, method='pbkdf2:sha256')
    user = User(username=username, email=email, password=hashed_password, is_admin=False)
    with user_db.session() as db_session:
        db_session.add(user)
        db_session.commit()
    return jsonify({"msg": "User created successfully"}), 201
